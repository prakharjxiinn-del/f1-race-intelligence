# Formula 1 Race Intelligence Analysis 🏎️

An interactive Tableau analytics project exploring Formula 1 driver and constructor performance, race strategy, circuit participation, reliability, DNFs, and podium achievements.

**Status:** Project starter kit. Add your actual dataset, completed Tableau workbook, and dashboard screenshots as you build and validate them.

## Project objectives
- Compare driver and constructor performance across seasons.
- Explore race outcomes by tyre compound and circuit, where data is available.
- Identify countries hosting the most Grand Prix events.
- Examine DNF patterns and race-completion reliability.
- Present findings through an interactive Tableau dashboard and Tableau Story.

## Tools
- Tableau Public or Tableau Desktop
- CSV / Excel data
- GitHub for version control and project documentation

## Repository structure
```text
f1-race-intelligence/
├── data/
│   ├── raw/
│   └── processed/
├── tableau/
│   └── README.md
├── screenshots/
├── docs/
│   ├── data_dictionary.md
│   └── dashboard_plan.md
├── .gitignore
├── LICENSE
└── README.md
```

## Dashboard plan
1. **Executive Overview:** KPI cards for races, drivers, constructors, podiums, and DNFs.
2. **Driver Performance:** points leaderboard by driver and season.
3. **Constructor Championship:** team points by season.
4. **Tyre Strategy:** outcomes by tyre compound and circuit type, if the dataset contains these fields.
5. **Circuit & Host Country:** Grand Prix event counts by country and circuit.
6. **Reliability & DNF:** DNF counts/reasons by driver, constructor, season, and circuit.
7. **Podium Analysis:** podiums by driver and constructor; nationality analysis if supported.
8. **Tableau Story:** a sequence of views presenting findings and evidence-based recommendations.

## Getting started
1. Select a dataset with clear source and licensing information.
2. Save the original file in `data/raw/`.
3. Document the source, coverage, field definitions, and license in `docs/data_dictionary.md`.
4. Clean missing values, standardize names, and check duplicates. Save analysis-ready data in `data/processed/`.
5. Connect Tableau to the cleaned CSV/Excel file.
6. Build and validate worksheets before combining them into dashboards.
7. Add filters for season, driver, constructor, circuit, and tyre compound when supported by the data.
8. Save the Tableau workbook in `tableau/`.
9. Export dashboard screenshots to `screenshots/`.
10. Update this README with the actual source, verified findings, limitations, and published dashboard link.

## Data quality and scope note
The project brief mentions **6,464 race records across 17 seasons**. Verify this against the dataset you actually use; public Formula 1 datasets vary in coverage and row granularity. Tyre compound, driver nationality, and detailed failure-type fields may not be available in every source. Do not invent missing fields or findings.

## Deliverables checklist
- [ ] Dataset source and license documented
- [ ] Data preprocessing documented
- [ ] Driver performance worksheet
- [ ] Constructor performance worksheet
- [ ] Tyre strategy worksheet (if data supports it)
- [ ] Host country / circuit worksheet
- [ ] DNF and reliability worksheet
- [ ] Podium worksheet
- [ ] Interactive Tableau dashboard
- [ ] Tableau Story
- [ ] Screenshots added
- [ ] Findings and limitations written
- [ ] Tableau Public link or workbook added

## Dashboard / demo
- Tableau Public: _Add your published link here_
- Workbook: add your `.twb` or `.twbx` file to `tableau/` if permitted.

## Author
- Name: _Add your name_
- Course / program: _Add your course_
- Project date: _Add date_
